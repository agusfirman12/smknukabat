

<?php $__env->startSection('main'); ?>
<div class="container border-bottom">
    <div class="row d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-2">
        <div class="col-9">
            <h2><?php echo e($announcement->title); ?></h2>
        </div>
        <div class="col">
            <a href="/admin/announcement" class="btn btn-success"><i class="bi bi-arrow-left"></i>Kembali</a>
            <a href="/admin/announcement/<?php echo e($announcement->id); ?>/edit" class="btn btn-warning"><i class="bi bi-pencil-square"></i>Edit</a>
            <form action="/admin/announcement/<?php echo e($announcement->id); ?>" method="POST" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin ?')"><i class="bi bi-trash"></i>Hapus</button>
              </form>
        </div>
    </div>
</div>
<div class="container pt-3">
    <img src="<?php echo e(asset('storage/'.$announcement->photo)); ?>" width="50%">
    <?php echo $announcement->annoucment_fill; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/admin/pengumuman/show.blade.php ENDPATH**/ ?>