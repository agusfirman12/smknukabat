

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-2 pb-2 mb-3 border-bottom">
        <h2>Banner Halaman Muka</h2>
    </div>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show col-lg-8" role="alert">
        <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <div class="table-responsive col-lg-10 rounded shadow py-3 px-3">
        <a href="/admin/banner/create" class="btn btn-success mb-3"><i class="bi bi-plus-circle pe-2"></i>Tambah Banner Baru</a>
        <table class="table table-bordered table-sm align-middle text-center">
          <thead>
            <tr>
              <th scope="col">No</th> 
              <th scope="col">Foto</th>
              <th scope="col">Judul Banner</th>
              <th scope="col">Aksi</th>
            </tr>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <td><img src="<?php echo e(asset('storage/'.$banner->photo)); ?>" width="250px"></td>
                <td><?php echo e($banner->title); ?></td>
                <td>
                  <a href="/admin/banner/<?php echo e($banner->id); ?>" class="btn btn-info"><i class="bi bi-eye"></i></a>
                  <a href="/admin/banner/<?php echo e($banner->id); ?>/edit"class="btn btn-warning"><i class="bi bi-pencil-square"></i></a>
                  <form action="/admin/banner/<?php echo e($banner->id); ?>}" method="POST" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger border-0" onclick="return confirm('Apakah Anda Yakin ?')"><i class="bi bi-trash"></i></button>
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/admin/banner/index.blade.php ENDPATH**/ ?>