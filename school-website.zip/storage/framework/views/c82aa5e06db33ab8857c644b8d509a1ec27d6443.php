

<?php $__env->startSection('main'); ?>
<section class="bg-light pb-5">
    <div class="container border-bottom text-center" style="padding-top: 100px">
        <div class="row d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-2">
                <h2><?php echo e($announcement->title); ?></h2>
        </div>
    </div>
    <div class="container col-7 pt-3 text-center shadow rounded-4 mt-2 pb-5">
        <img src="<?php echo e(asset('storage/'.$announcement->photo)); ?>" width="75%">
        <?php echo $announcement->annoucment_fill; ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/pengumuman/index.blade.php ENDPATH**/ ?>