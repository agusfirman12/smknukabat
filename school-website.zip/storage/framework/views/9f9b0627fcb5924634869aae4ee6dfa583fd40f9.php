

<?php $__env->startSection('main'); ?>
<div class="container mt-5">
      <div class="table-responsive col-lg-8 rounded shadow py-3 px-3">
          <table class="table table-bordered table-sm align-middle">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Foto</th>
                  <th scope="col">Judul Berita</th>
                  <th scope="col">Aksi</th>
                </tr>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                  <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($post->photo); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td>
                      <a href="/admin/berita/<?php echo e($post->id); ?>" class="badge bg-info"><i class="bi bi-eye"></i></a>
                      <a href=""class="badge bg-warning"><i class="bi bi-pencil-square"></i></a>
                      <a href="" class="badge bg-danger"><i class="bi bi-trash"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/admin/post/posts.blade.php ENDPATH**/ ?>