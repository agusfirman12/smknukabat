

<?php $__env->startSection('main'); ?>
    <section class="bg-light">
        <div class="hero-img">
            <div class="page-img">
                <?php if($post->photo): ?>
              <img class="p-img" src="<?php echo e(asset('storage/'.$post->photo)); ?>" width="100%">
              <?php else: ?>
              <img class="p-img" src="<?php echo e(asset('assets/img/news.png')); ?>" width="100%">
              <?php endif; ?>
            </div> 
        </div>
        <div class="container px-5 py-5">
            <div class="row d-flex justify-content-evenly">
                <div class="col-md-8">                       
                    <h2><?php echo e($post->title); ?></h2>
                    <div class="row">
                        <div class="col-2">
                            <p><i class="bi bi-person-fill pe-2"></i><?php echo e($post->user->name); ?></p>
                        </div>
                        <div class="col-2">
                            <p><i class="bi bi-calendar-fill pe-2"></i><?php echo e($post->created_at->format('d M Y')); ?></p>
                        </div>
                    </div>
                     <?php echo $post->post_fill; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/berita/index.blade.php ENDPATH**/ ?>