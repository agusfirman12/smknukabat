<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link href="<?php echo e(asset('assets/img/logo.png')); ?>" rel="icon">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="image-section justify-content-center d-flex mt-5">
                    <img class="mb-4" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" height="120px">
                </div>
                <div class="title text-center">
                    <h2>Selamat Datang, Admin</h2>
                    <h5>Di Sistem Website SMK NU Kabat</h5>
                </div>
                
                <?php if(session()->has('loginError')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('loginError')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <main class="form-signin bg-white px-3 py-4 rounded-3 shadow">
                    <form action="<?php echo e(route('login-process')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-center">
                            <h6>Silahkan Masukkan Username/Password Anda</h6>
                        </div>
                        <div class="form-floating">
                        <input type="text" name="username" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="username" autofocus required value="<?php echo e(old('username')); ?>">
                        <label for="username">Username</label>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-floating">
                        <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                        <label for="password">Password</label>
                        </div>

                        <button class="btn btn-primary w-100 py-2" type="submit">Login</button>
                    </form>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/admin/login.blade.php ENDPATH**/ ?>