

<?php $__env->startSection('main'); ?>
    <section class="bg-light">
        <div class="hero-img">
            <div class="page-img">
                <img class="p-img" src="<?php echo e(asset("assets/img/smknu-kabat.png")); ?>" alt="" width="100%">
            </div>
        </div>
        <div class="container px-5 py-5">
            <div class="row d-flex justify-content-evenly">
                <div class="col-md-3">
                  <?php echo $__env->make('profile.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-8">
                    <h2>Struktur Organisasi SMK NU Kabat</h2>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/profile/organisasi.blade.php ENDPATH**/ ?>