

<?php $__env->startSection('main'); ?>
    <section class="bg-light">
        <div class="hero-img">
            <div class="page-img">
                <img class="p-img" src="<?php echo e(asset("assets/img/smknu-kabat.png")); ?>" alt="" width="100%">
            </div>
        </div>
        <div class="container px-5 py-5">
            <div class="row d-flex justify-content-evenly">
                <div class="col-md-3">
                  <?php echo $__env->make('profile.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-8">
                    <h2>Pengajar SMK NU Kabat</h2>
                    <div class="row d-flex justify-content-evenly mt-4">
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 shadow d-flex justify-content-center p-3 rounded-3">
                            <div class="profile-info text-center">
                                <img src="<?php echo e(asset('storage/'.$item->photo)); ?>" width="150px" height="150px" class="rounded-circle">
                                <div class="fs-4 fw-semibold">
                                    <?php echo e($item->name); ?>

                                </div>
                                <div class="text-dark text-opacity-50">NIP. <?php echo e($item->nip); ?></div>
                                <div class="text-dark text-opacity-50">Guru <?php echo e($item->departemen); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/profile/pengajar.blade.php ENDPATH**/ ?>