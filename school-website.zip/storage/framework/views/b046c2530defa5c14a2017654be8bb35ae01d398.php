

<?php $__env->startSection('main'); ?>
<div class="container">
  <h2 class="dashboard-title pt-3">Dashboard</h2>
  <div class="link pb-4 pt-2">
    <a href="<?php echo e(route('dashboard')); ?>" class=" text-dark fs-5">Dasboard</a> > <a href="" class=" fs-5">Home</a>
  </div>
  <div class="row recap d-flex justify-content-evenly">
    <div class="col-md-3">
      <a href="/admin/teacher">
      <div class="card teacher-card py-4">
        <div class="icon-teacher">
            <i class="bi bi-briefcase-fill fs-1" style="color: white"></i>
          </div>
          <div class="card-body text-center">
            <div class="fw-semibold fs-5">Total Pengajar</div>
            <div class="fw-bold fs-4"><?php echo e($allTeacher); ?></div>
          </div>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <a href="/admin/announcement">
      <div class="card announcement-card py-4">
        <div class="icon-announcement">
            <i class="bi bi-megaphone-fill fs-1" style="color: white"></i>
          </div>
          <div class="card-body text-center">
            <div class="fw-semibold fs-5">Total Pengumuman</div>
            <div class="fw-bold fs-4"><?php echo e($allAnnouncement); ?></div>
          </div>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <a href="/admin/post">
        <div class="card news-card py-4">
          <div class="icon-news">
            <i class="bi bi-newspaper fs-1" style="color: white"></i>
          </div>
          <div class="card-body text-center">
            <div class="fw-semibold fs-5">Total Berita</div>
            <div class="fw-bold fs-4"><?php echo e($allPost); ?></div>
          </div>
        </div>
      </a>
    </div>
  </div>
  <div class="row mt-5 d-flex justify-content-evenly">
    <div class="col-md-8 shadow p-3 rounded-3">
      <div class="d-flex">
        <h5>Pengajar SMK NU Kabat</h5>
        <a href="/admin/teacher/create" class="btn mb-3 btn-sm ms-auto text-white" style="background-color: #1687A7"><i class="bi bi-plus-circle"></i></a>
      </div>
      <?php if(session()->has('success')): ?>
      <div class="alert alert-success alert-dismissible fade show col-lg-8" role="alert">
          <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>
  
      <div class="table-responsive py-3 px-3">
          <table class="table table-hover table-sm align-middle text-center">
            <thead>
              <tr>
                <th scope="col">nama</th>
                <th scope="col">Mengajar</th>
                <th scope="col">Email</th>
                <th scope="col">Nomor Hp</th>
                <th scope="col">Aksi</th>
              </tr>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                <tr>
                  <td>
                    <?php if($teacher->photo): ?>
                    <img src="<?php echo e(asset('storage/'.$teacher->photo)); ?>" width="40px" class="rounded-circle">
                    <?php else: ?>
                    <img src="<?php echo e(asset('assets/img/nophoto.png')); ?>" width="40" class="rounded-circle">
                    <?php endif; ?>
                    <?php echo e($teacher->name); ?>

                  </td>
                  <td><?php echo e($teacher->departemen); ?></td>
                  <td><?php echo e($teacher->email); ?></td>
                  <td><?php echo e($teacher->phone_number); ?></td>
                  <td>
                    <a href="/admin/teacher/<?php echo e($teacher->id); ?>/edit"class="text-secondary"><i class="bi bi-pencil-square"></i></a>
                    <form action="/admin/teacher/<?php echo e($teacher->id); ?>" method="POST" class="d-inline">
                      <?php echo method_field('delete'); ?>
                      <?php echo csrf_field(); ?>
                      <button class="text-secondary bg-white border-0" onclick="return confirm('Apakah Anda Yakin ?')"><i class="bi bi-trash"></i></button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      </div>
    </div>
    <div class="col-md-3 shadow ms-3 rounded-3 p-3">
      <h5>Berita Terbaru</h5>
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
      <div class="row pt-4">
        <div class="col-4">
          <?php if($post->photo): ?>
            <img src="<?php echo e(asset('storage/'.$post->photo)); ?>" width="75px" class="rounded">
          <?php else: ?>
            <img src="<?php echo e(asset('assets/img/news.png')); ?>" width="75px" class="rounded" >
          <?php endif; ?>
        </div>
        <div class="col">
          <a href="/admin/post/<?php echo e($post->id); ?>" class="fw-semibold text-dark"><?php echo e($post->title); ?></a>
          <br>
          <small class="text-dark text-opacity-50">post at. <?php echo e($post->created_at->format('d M Y')); ?></small>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Pengabdian\Website SMK NU Kabat\school-website\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>